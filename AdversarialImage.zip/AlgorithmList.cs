﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdversarialImage
{
    class AlgorithmList
    {
        public static int  length =0;

        public static int G00 = 1;
        public static int G01 = 2;
        public static int G10 = 3;
        public static int G11 = 4;



        public static int G000 = 1;
        public static int G001 = 2;
        public static int G010 = 3;
        public static int G011 = 4;
        public static int G100 = 1;
        public static int G101 = 2;
        public static int G110 = 3;
        public static int G111 = 4;


      


        public static int DoNothing = 1;
        public static int AdaptiveSmoothing = 2;
        public static int BilateralSmoothing = 3;
        public static int AdditiveNoise = 4;
        public static int Thinning = 5;
        public static int Pixellete = 6;
        public static int GussianBlur = 7;
        public static int Sharpening = 8;

       

    }
}
