﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdversarialImage
{
    public partial class Form1 : Form
    {

        public static System.Collections.ObjectModel.ObservableCollection<string> textlist = new System.Collections.ObjectModel.ObservableCollection<string>();
        public static System.Collections.ObjectModel.ObservableCollection<string> accuracytextlist = new System.Collections.ObjectModel.ObservableCollection<string>();
        string mnist_test = @"C:\Users\Cliff\Desktop\test\mnist\test"; //0
        string mnist_cw2 = @"C:\Users\Cliff\Desktop\test\mnist\cw2";//1
        string mnist_deepfool = @"C:\Cliff\kishor\Desktop\test\mnist\df";//2
        string mnist_fsgm = @"C:\Users\Cliff\Desktop\test\mnist\fsgm";//3
        string mnist_jsma = @"C:\Users\Cliff\Desktop\test\mnist\jsma";//4
        string mnist_adv = @"C:\Users\Cliff\Desktop\test\mnist\advgan";//5
        bool test = true;

        string cfiar_test = @"C:\Users\kishor\Desktop\icsw\test\cfiar\test";
        string cfiar_cw2 = @"C:\Users\kishor\Desktop\icsw\test\cfiar\cw2";
        string cfiar_deepfool = @"C:\Users\kishor\Desktop\icsw\test\cfiar\df";
        string cfiar_fsgm = @"C:\Users\kishor\Desktop\icsw\test\cfiar\fsgm";
        string cfiar_jsma = @"C:\Users\kishor\Desktop\icsw\test\cfiar\jsma";

        public static string clean = "";
        public static string adverse = "";

        public Form1()
        { 
            InitializeComponent();
            initiatedefault();
            textlist.CollectionChanged += Textlist_CollectionChanged;
            accuracytextlist.CollectionChanged += Accuracytextlist_CollectionChanged;
        }

        private void Accuracytextlist_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {

                richTextBox1.Text = richTextBox1.Text+"\n"+e.NewItems[0].ToString();

            }));
        }

        private void Textlist_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            this.Invoke(new MethodInvoker(delegate ()
            {
                string newtxt = e.NewItems[0].ToString();
                listBox1.Items.Add(e.NewItems[0]);
                if (newtxt.Contains("Iteration"))
                {
                    label7.Text = e.NewItems[0].ToString();
                }
                if (newtxt.Contains("Sequence "))
                {
                    textBox1.Text = newtxt.Replace("Sequence ", "");
                    string s = MainGA.recodedfilters.Where(l => l.Contains(textBox1.Text)).FirstOrDefault();
                  //  string s=textlist.Where(l => l.Contains(textBox1.Text+"x")).FirstOrDefault();
                    s = s.Replace(textBox1.Text+"x", "").Replace("cleanupperrange","").Replace("cleanlowerrange", ",").Replace(" ","");
                    var a = s.Split(',');
                    textBox2.Text = a[2];
                    textBox3.Text = a[3];
                    test = true;
                    testac();
                }

            }));
        
      
        }

        void initiatedefault()
        {
        clean = mnist_test;
        adverse = mnist_fsgm;
        }


        void initiatesettings()
        {
            Constant.population = (int)populationsize.Value;
            Constant.samplesize =  (int)imagetotal.Value;
            Constant.genelength = (int)algorithmnumber.Value;
            Constant.genesize = (int)genesize.Value;
            Constant.generation = (int)iterationnumber.Value;
            Constant.ThreadCount = (int)ThreadCount.Value;
            Constant.greyscale = checkBox1.Checked;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            initiatesettings();
            MainGA.ga();
            textBox1.Text = "Searching..";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                clean = folderBrowserDialog1.SelectedPath;
                listBox1.Items.Add("Clean Sample path: " + clean);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                adverse = folderBrowserDialog1.SelectedPath;
                listBox1.Items.Add("Adversarial Sample path: "+adverse);
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        void testac()
        {
            string algorithmseq = textBox1.Text;
            double upperrange = Double.Parse(textBox2.Text);
            double lowerrane = Double.Parse(textBox3.Text);
            Accuracy ac = new Accuracy();

            Task.Run(() => {

                ac.test(algorithmseq, upperrange, lowerrane);
                saveinfile();
            });
           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            initiatesettings();
            if (test)
            {
                testac();


            }
        }
        void saveinfile()
        {
            string[] lines = textlist.ToArray();
            this.Invoke(new MethodInvoker(delegate ()
            {
                lines[0] = richTextBox1.Text.ToString() + "\n";

            }));
            string n = string.Format("text-{0:yyyy-MM-dd_hh-mm-ss-tt}.txt",
          DateTime.Now);
            // WriteAllLines creates a file, writes a collection of strings to the file,
            // and then closes the file.  You do NOT need to call Flush() or Close().
            System.IO.File.WriteAllLines(n, lines);
        }
        private void button5_Click(object sender, EventArgs e)
        {
            HeuristicPopulation heuristicPopulation = new HeuristicPopulation();
            heuristicPopulation.ShowDialog();
        }
    }
}
