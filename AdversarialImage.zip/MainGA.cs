﻿using GeneticSharp.Domain;
using GeneticSharp.Domain.Chromosomes;
using GeneticSharp.Domain.Crossovers;
using GeneticSharp.Domain.Mutations;
using GeneticSharp.Domain.Populations;
using GeneticSharp.Domain.Selections;
using GeneticSharp.Domain.Terminations;
using GeneticSharp.Infrastructure.Framework.Threading;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AdversarialImage
{
    class MainGA
    {
        public static ObservableCollection<string> recodedfilters = new ObservableCollection<string>();
        public static int genelength = Constant.genesize;
       public static int indidvlength = Constant.genesize*Constant.genelength;
        public static int generationcount = 0;
        public static int inidvidualcount = 0;
        public static void ga()
        { genelength = Constant.genesize;
        indidvlength = Constant.genesize * Constant.genelength;
      
            var selection = new EliteSelection();
            var crossover = new TwoPointCrossover();
            var mutation = new FlipBitMutation();
            var fitness = new MyProblemFitness();
            var chromosome = new MyChromosome();
            var population = new Population(Constant.population, Constant.population, chromosome);

            var ga = new GeneticAlgorithm(population, fitness, selection, crossover, mutation);
            ga.MutationProbability = 0.1f;
            ga.Termination = new GenerationNumberTermination(Constant.generation);
        
            Console.WriteLine("GA running...");
            var taskExecutor = new TplTaskExecutor();
            taskExecutor.MinThreads = 100;
          
            taskExecutor.MaxThreads = 100;
           ga.TaskExecutor = taskExecutor;
            Task.Run(() => {
               
                ga.Start();
             
                Form1.textlist.Add("Best solution found has fitness "+ ga.BestChromosome.Fitness);

                var a = ga.BestChromosome.GetGenes();
                string s = "";
                foreach (var b in a)
                {
                    s = s + b.Value.ToString();
                }
                Console.WriteLine("Best solution found has {0} ", s);
                Form1.textlist.Add("Sequence "+ s);
            });
          //  t.Wait();

           // ga.Start();

         
        }

      public static  string printallchromosme(Gene[] a) {
            string s = "";
            foreach (var b in a)
            {
                s = s + b.Value.ToString();
            }
            Form1.textlist.Add(s);
         //   Console.WriteLine( s);
            return s;
        }
    }
}
