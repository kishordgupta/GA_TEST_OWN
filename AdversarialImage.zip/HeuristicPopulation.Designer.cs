﻿namespace AdversarialImage
{
    partial class HeuristicPopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox01 = new System.Windows.Forms.ComboBox();
            this.comboBox00 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBox111 = new System.Windows.Forms.ComboBox();
            this.comboBox110 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox101 = new System.Windows.Forms.ComboBox();
            this.comboBox100 = new System.Windows.Forms.ComboBox();
            this.comboBox011 = new System.Windows.Forms.ComboBox();
            this.comboBox010 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox001 = new System.Windows.Forms.ComboBox();
            this.comboBox000 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox11);
            this.groupBox1.Controls.Add(this.comboBox10);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox01);
            this.groupBox1.Controls.Add(this.comboBox00);
            this.groupBox1.Location = new System.Drawing.Point(39, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(221, 201);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "For Gene 2";
            // 
            // comboBox11
            // 
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox11.Location = new System.Drawing.Point(80, 147);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(121, 21);
            this.comboBox11.TabIndex = 7;
            this.comboBox11.SelectedIndexChanged += new System.EventHandler(this.comboBox11_SelectedIndexChanged);
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox10.Location = new System.Drawing.Point(80, 99);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(121, 21);
            this.comboBox10.TabIndex = 6;
            this.comboBox10.SelectedIndexChanged += new System.EventHandler(this.comboBox10_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "11";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(19, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "10";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "00";
            // 
            // comboBox01
            // 
            this.comboBox01.FormattingEnabled = true;
            this.comboBox01.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox01.Location = new System.Drawing.Point(80, 62);
            this.comboBox01.Name = "comboBox01";
            this.comboBox01.Size = new System.Drawing.Size(121, 21);
            this.comboBox01.TabIndex = 1;
            this.comboBox01.SelectedIndexChanged += new System.EventHandler(this.comboBox01_SelectedIndexChanged);
            // 
            // comboBox00
            // 
            this.comboBox00.FormattingEnabled = true;
            this.comboBox00.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox00.Location = new System.Drawing.Point(80, 19);
            this.comboBox00.Name = "comboBox00";
            this.comboBox00.Size = new System.Drawing.Size(121, 21);
            this.comboBox00.TabIndex = 0;
            this.comboBox00.SelectedIndexChanged += new System.EventHandler(this.comboBox00_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBox111);
            this.groupBox2.Controls.Add(this.comboBox110);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.comboBox101);
            this.groupBox2.Controls.Add(this.comboBox100);
            this.groupBox2.Controls.Add(this.comboBox011);
            this.groupBox2.Controls.Add(this.comboBox010);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.comboBox001);
            this.groupBox2.Controls.Add(this.comboBox000);
            this.groupBox2.Location = new System.Drawing.Point(338, 38);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(221, 355);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "For Gene 3";
            // 
            // comboBox111
            // 
            this.comboBox111.FormattingEnabled = true;
            this.comboBox111.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox111.Location = new System.Drawing.Point(70, 323);
            this.comboBox111.Name = "comboBox111";
            this.comboBox111.Size = new System.Drawing.Size(121, 21);
            this.comboBox111.TabIndex = 23;
            this.comboBox111.SelectedIndexChanged += new System.EventHandler(this.comboBox111_SelectedIndexChanged);
            // 
            // comboBox110
            // 
            this.comboBox110.FormattingEnabled = true;
            this.comboBox110.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox110.Location = new System.Drawing.Point(70, 275);
            this.comboBox110.Name = "comboBox110";
            this.comboBox110.Size = new System.Drawing.Size(121, 21);
            this.comboBox110.TabIndex = 22;
            this.comboBox110.SelectedIndexChanged += new System.EventHandler(this.comboBox110_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 323);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "111";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 278);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "110";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 241);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "101";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(24, 202);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "100";
            // 
            // comboBox101
            // 
            this.comboBox101.FormattingEnabled = true;
            this.comboBox101.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox101.Location = new System.Drawing.Point(70, 238);
            this.comboBox101.Name = "comboBox101";
            this.comboBox101.Size = new System.Drawing.Size(121, 21);
            this.comboBox101.TabIndex = 17;
            this.comboBox101.SelectedIndexChanged += new System.EventHandler(this.comboBox101_SelectedIndexChanged);
            // 
            // comboBox100
            // 
            this.comboBox100.FormattingEnabled = true;
            this.comboBox100.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox100.Location = new System.Drawing.Point(70, 195);
            this.comboBox100.Name = "comboBox100";
            this.comboBox100.Size = new System.Drawing.Size(121, 21);
            this.comboBox100.TabIndex = 16;
            this.comboBox100.SelectedIndexChanged += new System.EventHandler(this.comboBox100_SelectedIndexChanged);
            // 
            // comboBox011
            // 
            this.comboBox011.FormattingEnabled = true;
            this.comboBox011.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox011.Location = new System.Drawing.Point(70, 158);
            this.comboBox011.Name = "comboBox011";
            this.comboBox011.Size = new System.Drawing.Size(121, 21);
            this.comboBox011.TabIndex = 15;
            this.comboBox011.SelectedIndexChanged += new System.EventHandler(this.comboBox011_SelectedIndexChanged);
            // 
            // comboBox010
            // 
            this.comboBox010.FormattingEnabled = true;
            this.comboBox010.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox010.Location = new System.Drawing.Point(70, 110);
            this.comboBox010.Name = "comboBox010";
            this.comboBox010.Size = new System.Drawing.Size(121, 21);
            this.comboBox010.TabIndex = 14;
            this.comboBox010.SelectedIndexChanged += new System.EventHandler(this.comboBox010_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 158);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "011";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "010";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "001";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "000";
            // 
            // comboBox001
            // 
            this.comboBox001.FormattingEnabled = true;
            this.comboBox001.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox001.Location = new System.Drawing.Point(70, 73);
            this.comboBox001.Name = "comboBox001";
            this.comboBox001.Size = new System.Drawing.Size(121, 21);
            this.comboBox001.TabIndex = 9;
            this.comboBox001.SelectedIndexChanged += new System.EventHandler(this.comboBox001_SelectedIndexChanged);
            // 
            // comboBox000
            // 
            this.comboBox000.FormattingEnabled = true;
            this.comboBox000.Items.AddRange(new object[] {
            "Do Nothing",
            "Adaptive Smoothing",
            "Bilateral Smoothing",
            "Additive Noise",
            "Thining",
            "Pixellete",
            "Gaussian Blur",
            "Sharpening"});
            this.comboBox000.Location = new System.Drawing.Point(70, 30);
            this.comboBox000.Name = "comboBox000";
            this.comboBox000.Size = new System.Drawing.Size(121, 21);
            this.comboBox000.TabIndex = 8;
            this.comboBox000.SelectedIndexChanged += new System.EventHandler(this.comboBox000_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(76, 353);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 29);
            this.button1.TabIndex = 2;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // HeuristicPopulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "HeuristicPopulation";
            this.Text = "HeuristicPopulation";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox01;
        private System.Windows.Forms.ComboBox comboBox00;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox111;
        private System.Windows.Forms.ComboBox comboBox110;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox101;
        private System.Windows.Forms.ComboBox comboBox100;
        private System.Windows.Forms.ComboBox comboBox011;
        private System.Windows.Forms.ComboBox comboBox010;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox001;
        private System.Windows.Forms.ComboBox comboBox000;
        private System.Windows.Forms.Button button1;
    }
}