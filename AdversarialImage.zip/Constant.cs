﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdversarialImage
{
    class Constant
    {
        public static int samplesize = 10;
        public static int generation = 6;
        public static int population = 6;
        public static int genesize = 2;
        public static int genelength = 4;

        public static int ThreadCount = 3;
        internal static bool greyscale=false;
    }
}
