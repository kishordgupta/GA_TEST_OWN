﻿using GeneticSharp.Domain.Chromosomes;
using GeneticSharp.Domain.Fitnesses;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdversarialImage
{
    class MyProblemFitness: IFitness
    {
     
        public double Evaluate(IChromosome chromosome)
        {
            string a = MainGA.printallchromosme(chromosome.GetGenes());
            MainGA.inidvidualcount++;
            Form1.textlist.Add("Fitness running for individual "+a +" pindiviudalnumber "  + MainGA.inidvidualcount);
            if (MainGA.inidvidualcount ==Constant.population)
            {
                MainGA.inidvidualcount = 0;
                MainGA.generationcount++;
                Form1.textlist.Add("GA Iteration " + MainGA.generationcount);
            }
        
            if (MainGA.recodedfilters.Where(l => l.Contains(a)).Any())
            {

                string s = MainGA.recodedfilters.Where(l => l.Contains(a)).FirstOrDefault();
                var b = s.Split(',');
                Form1.textlist.Add(a + " fitness " + b[1]);
                Form1.textlist.Add(a + " cleanupperrange " + b[2] + " cleanlowerrange " + b[3]);
                Form1.textlist.Add("old seq");
                return Double.Parse(b[0]);
            }

            
            // Evaluate the fitness of chromosome.
           
            //  fitnesstcheck(chromosome);
            RunAlgorithm r = new RunAlgorithm();

          
            return r.RunAlgorithmchromosomes(chromosome);
        }

        
    }
}
